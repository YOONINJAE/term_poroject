﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cddsdsdsdsd
{
    public partial class Form1 : Form
    {
        double xmin = -2, xmax = 7;
        double ymin = -5, ymax = 70;
        private float xpixel(double xw)
        {
            return (float)(PicDraw.ClientSize.Width * (xw - xmin) / (xmax - xmin));
        }
        private float ypixel(double yw)
        {
            return (float)(PicDraw.ClientSize.Height * (1 - (yw - ymin) / (ymax - ymin)));
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnDraw_Click(object sender, EventArgs e)
        {
            //데이터 세팅
            const int ndat = 6; //설계 의도 분명히
            double[] xw = new double[ndat] { 1, 2, 3, 4, 5, 6 };
            double[] yw = new double[ndat] { 2.1, 7.7, 13.6, 27.2, 40.9, 61.1 };

            //좌표계
            Graphics grp = PicDraw.CreateGraphics();
            grp.DrawLine(new Pen(Color.Black), xpixel(xmin), ypixel(0),
                                                xpixel(xmax), ypixel(0));
            grp.DrawLine(new Pen(Color.Black), xpixel(0), ypixel(ymin),
                                                xpixel(0), ypixel(ymax));

            //데이터 점 그리기
            for (int i = 0; i < ndat; i++)
            {
                grp.DrawEllipse(new Pen(Color.Red), xpixel(xw[i]), ypixel(yw[i]), 2, 2);
            }

            //Least square풀이
            double sumXY = 0, sumXXY = 0, sumX = 0, sumY = 0, sumXX = 0, sumXXX = 0, sumXXXX = 0;
            for (int i = 0; i < ndat; i++)
            {
                sumX = sumX + xw[i];
                sumY = sumY + yw[i];
                sumXX = sumXX + xw[i] * xw[i];
                sumXXX = sumXXX + xw[i] * xw[i] * xw[i];
                sumXXXX = sumXXXX + xw[i] * xw[i] * xw[i] * xw[i];
                sumXY = sumXY + xw[i] * yw[i];
                sumXXY = sumXXY + xw[i] * xw[i] * yw[i];
            }

            //크레이머 룰
            double Eq0 = 0, Eq1 = 0, Eq2 = 0, Eq3 = 0;
            Eq0 = ndat * (sumXX * sumXXXX - sumXXX * sumXXX) - sumX * (sumX * sumXXXX - sumXXX * sumXX)
                  + sumXX * (sumX * sumXXX - sumXX * sumXX);
            Eq1 = sumY * (sumXX * sumXXXX - sumXXX * sumXXX) - sumX * (sumXY * sumXXXX - sumXXX * sumXXY)
                  + sumXX * (sumXY * sumXXX - sumXX * sumXXY);
            Eq2 = ndat * (sumXY * sumXXXX - sumXXX * sumXXY) - sumY * (sumX * sumXXXX - sumXXX * sumXX)
                  + sumXX * (sumX * sumXXY - sumXY * sumXX);
            Eq3 = ndat * (sumXX * sumXXY - sumXY * sumXXX) - sumX * (sumX * sumXXY - sumXY * sumXX)
                  + sumY * (sumX * sumXXX - sumXX * sumXX);
            double a0 = Eq1 / Eq0;
            double a1 = Eq2 / Eq0;
            double a2 = Eq3 / Eq0;
            //구해진 포물선 그리기
            int nseg = 100;
            double size = (xmax - xmin) / nseg;
            for (int j = 0; j < nseg; j++)
            {
                double xL = xmin + size * j;//점이 찍히는 다음 x지점..
                double xR = xL + size;      //점이 찍히a는 다음 x지점의 다음지점!
                double yL = ymin + size * j;
                double yR = yL + size;
                grp.DrawLine(new Pen(Color.Blue), xpixel(xL), ypixel(a0 + a1 * xL + a2 * xL * xL),
                                                    xpixel(xR), ypixel(a0 + a1 * xR + a2 * xR * xR));

            }
        }
    }
}