﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MonteRect
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Random rnd = new Random();
        private void BtnStart_Click(object sender, EventArgs e)
        {

            //Real ratio
            int wd = PicArea.ClientSize.Width;
            int ht = PicArea.ClientSize.Height;
            int area = wd * ht;
            //P0,P1,P2 세개의 점
            int x1 = 160, x2 = 50, x3 = 340;
            int y1 = 70, y2 = 410, y3 = 290;

            double S0 = triCalculate_S0(x1, y1);
            double ratio_real = S0 / (double)area;

            lblRatioReal.Text = string.Format("{0:0.000000}", ratio_real);//소수점 네 자리까지 나타내라. {}서식의미

            //Graphics 객체 만들기
            Graphics grp = PicArea.CreateGraphics();
            grp.Clear(Color.White);

            //Monte carlo simulation
            int npoint = 20000;
            int nIN = 0, nOUT = 0;

            for (int i = 0; i < npoint; i++)
            {
                int xp = rnd.Next(wd);
                int yp = rnd.Next(ht);

                //한 점에 따른 세 개의 삼각형 넓이.
                double S1 = triCalculate_S1(xp, yp);
                double S2 = triCalculate_S2(xp, yp);
                double S3 = triCalculate_S3(xp, yp);

                //판단.. 
                Judgement(S1,S2,S3,xp,yp);
                
            }
            //정보출력
            lblIn.Text = Convert.ToString(nIN);
            lblOut.Text = Convert.ToString(nOUT);
            double Ratio_monte = (double)nIN / (double)(nIN + nOUT);
            lblRatioMonte.Text = string.Format("{0:0.000000}", Ratio_monte);

            //함수
            void Judgement (double S1,double S2,double S3,int xp, int yp)
            {
                bool isIN = (S1 < 0 && S2 < 0 && S3 < 0) || (S1 > 0 && S2 > 0 && S3 > 0);
                Color col;
                if (isIN)
                {
                    nIN++;
                    col = Color.Black;
                }
                else
                {
                    nOUT++;
                    col = Color.Gray;
                }
                grp.DrawEllipse(new Pen(col), xp, yp, 1, 1);
            }

            double triCalculate_S0(int x0, int y0)//삼각형0 면적 계산..
            {
                double result = (double)1 / 2 * ((x0 * y2 + x2 * y3 + x3 * y0) - (x0 * y3 + x3 * y2 + x2 * y0));

                return result;
            }

            double triCalculate_S1(int x0, int y0)//삼각형1 면적 계산..
            {
                double result = (double)1 / 2 * ((x0 * y1 + x1 * y2 + x2 * y0) - (x0 * y2 + x2 * y1 + x1 * y0));
                return result;
            }


            double triCalculate_S2(int x0, int y0)//삼각형2 면적 계산..
            {
                double result = (double)1 / 2 * ((x0 * y2 + x2 * y3 + x3 * y0) - (x0 * y3 + x3 * y2 + x2 * y0));
                return result;
            }


            double triCalculate_S3(int x0, int y0)//삼각형 3면적 계산..
            {
                double result = (double)1 / 2 * ((x0 * y3 + x3 * y1 + x1 * y0) - (x0 * y1 + x1 * y3 + x3 * y0));
                return result;
            }
        }
    }
}
